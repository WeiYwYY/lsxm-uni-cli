import auth from './apis/auth.js'
import user from './apis/user.js'
export default{
	apis:{
		auth,
		user
	}
}